﻿namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            // 03. ADD Family member!!!

            //Family family = new Family();

            // int n = int.Parse(Console.ReadLine());

            //  for (int i = 0; i < n; i++)
            //{
            //    string[] inputPeople = Console.ReadLine().Split(" ", 
            //      StringSplitOptions.RemoveEmptyEntries);

            //    Person person = new Person(inputPeople[0], int.Parse(inputPeople[1]));

            //   family.People.Add(person);


            //  }
            // Person oldestPerson = family.ReturnMember();
            // Console.WriteLine($"{oldestPerson.Name} {oldestPerson.Age}");
            //}
            //}
            //}

            // 04. Opinin poll
            List<Person> olderthan30 = new List<Person>();

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                string[] inputPeople = Console.ReadLine().Split(" ", 
                    StringSplitOptions.RemoveEmptyEntries);

                Person person = new Person(inputPeople[0], int.Parse(inputPeople[1]));

                if (person.Age > 30)
                {
                        olderthan30.Add(person);
                }
            }

            foreach (var person in olderthan30.OrderBy(p => p.Name))
            {
                Console.WriteLine($"{person.Name} - {person.Age}");
            }
        }
    }
}

        